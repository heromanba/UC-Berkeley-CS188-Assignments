STUDENT_CODE_DEFAULT = 'multiAgents.py,solveTicTacToe.py'
PROJECT_TEST_CLASSES = 'multiagentTestClasses.py'
PROJECT_NAME = 'Project 2: Multiagent search'
BONUS_PIC = False
